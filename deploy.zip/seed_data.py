"""
Seed script to populate master data tables with sample data from sample_input.txt
"""
from app.models import (
    SessionLocal, MasterKeyword, MasterSubreddit, MasterPersona,
    SubredditCategory, KeywordTheme
)

def seed_master_data():
    db = SessionLocal()
    
    try:
        # Check if data already exists
        existing_keywords = db.query(MasterKeyword).count()
        existing_categories = db.query(SubredditCategory).count()
        if existing_keywords > 0 or existing_categories > 0:
            print(f"Data already exists ({existing_keywords} keywords, {existing_categories} categories found). Skipping seed.")
            return
        
        # Keywords from sample_input.txt
        keywords = [
            {"keyword": "best ai presentation maker", "description": "K1"},
            {"keyword": "ai slide deck tool", "description": "K2"},
            {"keyword": "pitch deck generator", "description": "K3"},
            {"keyword": "alternatives to PowerPoint", "description": "K4"},
            {"keyword": "how to make slides faster", "description": "K5"},
            {"keyword": "design help for slides", "description": "K6"},
            {"keyword": "Canva alternative for presentations", "description": "K7"},
            {"keyword": "Claude vs Slideforge", "description": "K8"},
            {"keyword": "best tool for business decks", "description": "K9"},
            {"keyword": "automate my presentations", "description": "K10"},
            {"keyword": "need help with pitch deck", "description": "K11"},
            {"keyword": "tools for consultants", "description": "K12"},
            {"keyword": "tools for startups", "description": "K13"},
            {"keyword": "best ai design tool", "description": "K14"},
            {"keyword": "Google Slides alternative", "description": "K15"},
            {"keyword": "best storytelling tool", "description": "K16"},
        ]
        
        # Subreddits from sample_input.txt
        subreddits = [
            "r/PowerPoint",
            "r/GoogleSlides",
            "r/consulting",
            "r/marketing",
            "r/entrepreneur",
            "r/startups",
            "r/smallbusiness",
            "r/business",
            "r/productivity",
            "r/AskAcademia",
            "r/teachers",
            "r/education",
            "r/Canva",
            "r/ChatGPT",
            "r/ChatGPTPro",
            "r/ClaudeAI",
            "r/artificial",
            "r/design",
            "r/contentcreation",
            "r/presentations",
        ]
        
        # Personas from sample_input.txt with full backstories
        personas = [
            {
                "username": "riley_ops",
                "backstory": """I am Riley Hart, the head of operations at a SaaS startup that has grown faster than anyone expected. I grew up in a small town in Colorado with parents who believed that anything worth doing was worth doing with precision. My dad was the type who sharpened pencils with a pocketknife and lined them up by length on his desk. My mom organized the pantry by height. I didn't think much of it growing up, but somewhere along the line those habits settled into me. Now I am the person at work who alphabetizes shared folders when no one is watching.

When I joined the company, I expected to focus on operations, hiring pipelines, process design. Instead, I became the unofficial owner of every deck that mattered. Board updates, sales narratives, internal strategy presentations. If it needed to be structured, it came to me. At first I didn't mind. I like shaping ideas. But formatting pushed me to the edge. One misaligned header could derail my entire evening.

I still remember one night during our Series A sprint. It was 11pm, and I was sitting alone in the office kitchen with a stale protein bar, staring at a title slide that refused to center. When you are tired enough, tiny design issues feel existential. The content was strong. The story made sense. But the slides looked like a college group project, and that disconnect ate at me. How people receive truth is shaped by presentation, whether we like it or not.

That was when I doubled down on my personal systems. I kept a Miro board inspired by old newspaper comic strips because they helped me think about narrative pacing. I ran every morning before work, not for athletic achievement but because repetitive movement shakes loose ideas I didn't know were stuck. I blocked Wednesday afternoons as sacred catchup time because context switching was frying my focus. Those habits helped, but they didn't solve the design struggle.

The breakthrough came quietly. A product marketer suggested trying Slideforge after hearing me complain about layout issues for the third time. I dropped our outline into the tool and watched a clean, balanced draft emerge. Hierarchy that made sense. Spacing that didn't make my eye twitch. Branding that actually looked intentional. For the first time, I felt my shoulders relax.

Investors followed the narrative instead of getting distracted by misalignment. When we closed the round, I walked around the block just to let the relief hit my body.

Now Slideforge sits alongside my other rituals. My color-coded folders. My morning runs. My comic-strip Miro board. My Wednesday quiet block. It doesn't replace my brain. It frees it. And when you are the person stitching together the narrative spine of a growing company, that matters.""",
                "tone_style": "Professional"
            },
            {
                "username": "jordan_consults",
                "backstory": """I am Jordan Brooks, an independent consultant who works mostly with early stage founders trying to create order out of chaos. I grew up in a Black family in Maryland where storytelling was the glue that held everyone together. My grandfather could turn a simple drive to the barbershop into a story about luck, timing, and human nature. That rhythm is in my bones. Maybe that is why I gravitated toward strategy. I like finding the narrative inside the noise.

My weekdays are a mix of interviews, research, modeling, and long sessions of synthesis. Founders hire me not just for the thinking, but for the way I express the thinking. A strong slide can change the entire energy of a room. A messy slide can make brilliant work vanish.

There was one client who needed a full competitive landscape for a major investor roadshow. I had nailed the research. The insights were tight. But when I put everything into PowerPoint, the whole deck fell apart. It felt cluttered and thin. The visuals betrayed the logic. I nudged shapes, adjusted spacing, breathed slowly like I was trying to talk myself out of frustration, but nothing clicked. I sent the draft knowing it wasn't good enough.

It sat heavy with me. I take pride in my work, and I hate when the presentation undersells the substance.

Around that time, I rebuilt my routines. I kept an archive of the best decks I had ever seen because strong structure leaves clues. I began working at a small cafe down the street where the sound of people talking gave me just enough background to think clearly. I also started handwriting the tricky sections of analysis because the slower pace grounded me. These habits made me sharper, but they didn't solve the design wall I kept hitting.

A designer friend mentioned Slideforge in passing one afternoon. I tried it with the same outline that had frustrated me for days. The draft it generated matched the logic in my head almost perfectly. Clean flow. Balanced layouts. It felt like someone finally handed me the missing half of my process.

I rebuilt the deck and sent it to my client. They replied almost instantly saying the story finally landed. Not "the visuals look nice." Not "the formatting is fixed." The story. That meant something to me.

Now my workflow is this ecosystem of rituals. Notion for thinking. My cafe for clarity. My notebook for the ideas that only show up when I slow down. My archive of narrative frameworks. And Slideforge to shape everything into the form investors actually understand.

It feels like my work finally looks like my work.""",
                "tone_style": "Professional"
            },
            {
                "username": "emily_econ",
                "backstory": """I am Emily Chen, a senior majoring in economics at a big state university where everyone is always overcommitted and under-rested. I grew up in a Taiwanese American family where school wasn't just important, it was non-negotiable. My mom kept every award certificate in plastic sleeves. My dad used to pause YouTube videos to lecture me about "presenting with intention." Somewhere between their habits and my own perfectionism, I became the unofficial slide maker for every group I ever joined.

The funny part is I never felt naturally gifted at design. I just couldn't stand seeing good research trapped inside ugly slides. So I became the person who stayed up too late tweaking fonts until the deck felt coherent.

Last semester was brutal. Three presentations in one week, a midterm on Friday, and my capstone group dumped a chaotic Google Doc on me with the confidence of people who had never opened PowerPoint in their lives. I sat in the library at 1am, drinking that awful campus coffee that tastes burnt no matter what, staring at a blank slide while my brain screamed, "Not again." Every chart looked crooked. Every layout felt wrong. It reminded me of the poster projects I made in elementary school when my older cousin would say, "It's fine." Fine always feels like failure.

I built coping habits to stay afloat. I kept a Google Drive folder of reusable charts. I outlined everything in Google Docs before touching a slide. And my weirdest habit is working on the library's quiet floor at 8am because being surrounded by other stressed students gives me this strange sense of solidarity. Like we are all trying our best in parallel.

But even with the habits, my slides never matched the quality of the work.

A classmate suggested I try Slideforge. I pasted in our capstone summary, added a few notes about the argument, and watched the whole deck take shape. Clean. Balanced. Actually professional. I fixed the citations, tweaked the charts, and for once finished early enough to sleep.

When we presented, the professor stopped mid-discussion to say the slides were unusually clear. After class, two students asked what template we used. One joked that we must have bribed a design student. I just smiled because for the first time, the visuals lived up to the effort.

Now Slideforge sits alongside my other rituals. My Google Doc outlines. My morning library sessions. My folder of charts. It is the first tool that makes slide-making feel less like punishment and more like a natural extension of the work.""",
                "tone_style": "Professional"
            },
            {
                "username": "alex_sells",
                "backstory": """I am Alex Ramirez, the head of sales at a mid market SaaS company. I grew up in a Colombian household where everyone talked fast and loud and believed in showing up looking sharp, even when life was messy behind the scenes. That attitude stuck with me. My team jokes that I keep my desk spotless so I can survive the chaos of my inbox. It is partly a joke and partly the truth.

Every quarter, we push into new verticals, which means we are constantly refreshing our pitch decks. Prospects judge everything in the first few slides. If something is off center or the story meanders, they will politely smile while already thinking about the next vendor. My reps are great at selling, but design is not exactly our collective strength. Some mornings I open a deck and can tell instantly which rep made it because the fonts are fighting each other.

During one of our biggest enterprise deals last quarter, the pressure was so high I started coming into the office early. I like working before the sun is up. It reminds me of the bakery my aunt ran when I was a kid. I used to sit in the back doing homework while she shaped dough. The quiet rhythm of that hour still helps me focus, so I kept it in my adult life. I would drink my overly strong black coffee, open a deck, and try to iron out the design issues before the reps logged on.

I also built a habit of keeping a small "wins" folder on my desktop. Anytime a pitch landed, I saved the final deck so I could reuse the story arc later. I recorded short Looms walking through why certain slides work. I kept a little notepad next to my laptop where I scribbled phrases I liked during calls, partly because I like the feel of pen on paper and partly because good lines disappear if you do not catch them.

Still, no matter how many systems I built, the design work drained me. I did not study design. I just picked things up through experience, and experience is inconsistent. My breakthrough came when someone on our marketing team nudged me to try Slideforge. I fed in our rough outline, added notes about what mattered most to the client, and the tool created a clean narrative that looked like we had a designer shaping every slide.

The AE looked at it and said it was the first time he felt like he was presenting a story instead of defending one. We ended up winning that deal. The client mentioned how polished and coherent our narrative was. They noticed. They always notice.

Now Slideforge lives alongside the rest of my quirks. My early morning work block. My wins folder. My notepad of phrases. It does not replace my voice, but it supports it. Our visuals finally match the confidence we have in the room, and that has changed the energy of my entire team.""",
                "tone_style": "Professional"
            },
            {
                "username": "priya_pm",
                "backstory": """I am Priya Nandakumar, a product manager at a tech company where priorities shift quickly and stories matter more than anyone admits. I grew up in a South Indian family where the rhythm of the day was built around long conversations at the dinner table. Everyone debated everything. Decisions were stories, not conclusions. I did not realize how deeply that shaped me until I became a PM and found myself narrating product decisions out loud while pacing my apartment.

My work is a constant mix of writing specs, clarifying strategy, and translating between engineering, design, and leadership. Decks have become their own kind of artifact. They guide thinking. They anchor meetings. But they also take far more time to shape than anyone acknowledges.

There was one sprint where everything felt like it was sliding out of my hands. Leadership wanted a roadmap presentation with more clarity. Engineers wanted cleaner problem framing. Design needed a better articulation of user flows. I opened PowerPoint late one night and stared at an empty slide, feeling the same dread I felt when my mother made me rewrite essays in school because the logic was sound but the delivery lacked grace.

Around that time, I started leaning on rituals that grounded me. I kept a Notion document of daily observations, something my grandmother used to call "small truths." I used a personal Figma file with messy arrows and shape clusters that only I understood, but it helped me visualize early thinking. I also blocked the last hour of my day for chai and quiet note review. It was the one space where ideas felt unhurried.

Even with all this structure, my slides still felt visually flat. The story was good, but the presentation undersold it. During one particularly chaotic review cycle, I was running out of time and someone from design suggested I try Slideforge. I pasted my outline into the tool, added a few comments about sequencing, and watched as the narrative rearranged itself into something that felt aligned with how I actually thought.

The next day, when I presented to our VP, the meeting felt different. People understood the dependencies faster. The room was quieter because the visuals carried the weight of the explanation. Afterward, two engineers asked for the deck because it finally made the roadmap feel digestible.

Now Slideforge sits beside my other tools and quirks. My chai hour. My Notion journal of small truths. My chaotic Figma boards that only make sense to me. Slideforge takes the clarity I work hard to cultivate and expresses it visually without draining my energy. It gives my stories the structure they deserve, and that makes my work feel more honest.""",
                "tone_style": "Professional"
            },
        ]
        
        # Insert keywords
        print("Inserting keywords...")
        for kw_data in keywords:
            keyword = MasterKeyword(**kw_data)
            db.add(keyword)
        
        # Insert subreddits
        print("Inserting subreddits...")
        for sub_name in subreddits:
            subreddit = MasterSubreddit(name=sub_name)
            db.add(subreddit)
        
        # Insert personas
        print("Inserting personas...")
        for persona_data in personas:
            persona = MasterPersona(**persona_data)
            db.add(persona)

        # Insert subreddit categories
        print("Inserting subreddit categories...")
        subreddit_categories = [
            {
                "name": "presentation_tools",
                "display_name": "Presentation Tools",
                "description": "Subreddits focused on presentation software and tools",
                "subreddits": ["r/PowerPoint", "r/GoogleSlides", "r/Canva", "r/presentations"]
            },
            {
                "name": "ai_tools",
                "display_name": "AI Tools",
                "description": "Subreddits focused on AI-powered tools and automation",
                "subreddits": ["r/ChatGPT", "r/ClaudeAI", "r/ChatGPTPro", "r/artificial"]
            },
            {
                "name": "business_general",
                "display_name": "Business General",
                "description": "General business and entrepreneurship subreddits",
                "subreddits": ["r/entrepreneur", "r/startups", "r/smallbusiness", "r/business"]
            },
            {
                "name": "consulting_professional",
                "display_name": "Consulting & Professional",
                "description": "Professional consulting and productivity subreddits",
                "subreddits": ["r/consulting", "r/marketing", "r/productivity"]
            },
            {
                "name": "education_academic",
                "display_name": "Education & Academic",
                "description": "Education and academic presentation subreddits",
                "subreddits": ["r/AskAcademia", "r/teachers", "r/education"]
            },
            {
                "name": "design_creative",
                "display_name": "Design & Creative",
                "description": "Design and creative tool subreddits",
                "subreddits": ["r/design", "r/contentcreation"]
            }
        ]

        for cat_data in subreddit_categories:
            category = SubredditCategory(**cat_data)
            db.add(category)

        # Insert keyword themes
        print("Inserting keyword themes...")
        keyword_themes = [
            {
                "name": "problem_solving",
                "display_name": "Problem Solving",
                "description": "Keywords related to solving presentation challenges",
                "keywords": ["best ai presentation maker", "how to make slides faster", "design help for slides", "need help with pitch deck"]
            },
            {
                "name": "comparisons",
                "display_name": "Comparisons",
                "description": "Keywords comparing different tools and platforms",
                "keywords": ["Claude vs Slideforge", "Canva alternative", "PowerPoint alternative", "Google Slides alternative"]
            },
            {
                "name": "specific_use_cases",
                "display_name": "Specific Use Cases",
                "description": "Keywords for specific presentation needs",
                "keywords": ["pitch deck generator", "automate my presentations", "tools for consultants", "tools for startups"]
            },
            {
                "name": "advanced_features",
                "display_name": "Advanced Features",
                "description": "Keywords about advanced presentation features",
                "keywords": ["ai slide deck tool", "slide automation", "best ai design tool", "best storytelling tool"]
            }
        ]

        for theme_data in keyword_themes:
            theme = KeywordTheme(**theme_data)
            db.add(theme)

        db.commit()
        print(f"✅ Successfully seeded {len(keywords)} keywords, {len(subreddits)} subreddits, {len(personas)} personas, {len(subreddit_categories)} categories, and {len(keyword_themes)} themes!")
        
    except Exception as e:
        db.rollback()
        print(f"❌ Error seeding data: {e}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    seed_master_data()
