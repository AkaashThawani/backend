#!/bin/bash

# Initialize database before deployment
python init_db.py

# Optional: Seed data (uncomment if needed)
# python seed_data.py
